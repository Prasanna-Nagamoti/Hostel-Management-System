import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Gallery {

 JFrame Gallery;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gallery window = new Gallery();
					window.Gallery.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Gallery() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Gallery = new JFrame();
		Gallery.getContentPane().setBackground(new Color(255, 204, 204));
		Gallery.setBounds(0, 0, 1330, 750);
		Gallery.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Gallery.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Hostel Gallery");
		lblNewLabel.setBounds(541, 22, 283, 34);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD, 25));
		Gallery.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(10, 78, 397, 258);
		lblNewLabel_1.setIcon(new ImageIcon(Gallery.class.getResource("/images/room.jpg")));
		Gallery.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(Gallery.class.getResource("/images/room2.jpg")));
		lblNewLabel_2.setBounds(454, 78, 397, 258);
		Gallery.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Gallery.class.getResource("/images/mess.jpg")));
		lblNewLabel_3.setBounds(911, 78, 379, 258);
		Gallery.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Hostel AC Room");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(90, 347, 210, 24);
		Gallery.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Hostel Non AC Room");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(557, 347, 182, 24);
		Gallery.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Hostel Mess");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(1040, 347, 125, 21);
		Gallery.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setIcon(new ImageIcon(Gallery.class.getResource("/images/ground.jpg")));
		lblNewLabel_7.setBounds(10, 410, 397, 220);
		Gallery.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setIcon(new ImageIcon(Gallery.class.getResource("/images/hostelgym-hektorhostel.jpg")));
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setBounds(454, 410, 397, 220);
		Gallery.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setIcon(new ImageIcon(Gallery.class.getResource("/images/pool.jpg")));
		lblNewLabel_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_9.setBounds(911, 410, 379, 220);
		Gallery.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Hostel Play Ground");
		lblNewLabel_10.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_10.setBounds(118, 641, 182, 24);
		Gallery.getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Hostel Gym");
		lblNewLabel_11.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_11.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_11.setBounds(578, 641, 161, 21);
		Gallery.getContentPane().add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("Hostel Swiming Pool");
		lblNewLabel_12.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_12.setBounds(1044, 641, 146, 21);
		Gallery.getContentPane().add(lblNewLabel_12);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				home h=new home();
				h.home.setVisible(true);
			}
		});
		btnNewButton.setIcon(new ImageIcon(Gallery.class.getResource("/images/Close all jframe.png")));
		btnNewButton.setBounds(1241, 11, 63, 34);
		Gallery.getContentPane().add(btnNewButton);
	}

}
