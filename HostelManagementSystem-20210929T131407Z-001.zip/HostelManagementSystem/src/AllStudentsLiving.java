import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
public class AllStudentsLiving {

	private JFrame AllStudentsLiving;
	private JTable table;
	private JScrollPane scrollPane;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AllStudentsLiving window = new AllStudentsLiving();
					window.AllStudentsLiving.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AllStudentsLiving() {
		initialize();
		
		DefaultTableModel model=(DefaultTableModel)table.getModel();
		table.setAutoResizeMode(table.AUTO_RESIZE_OFF);
		
		lblNewLabel = new JLabel("Students Details");
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD, 20));
		lblNewLabel.setBounds(10, 11, 282, 32);
		AllStudentsLiving.getContentPane().add(lblNewLabel);
		try
		{
			Class.forName("com.sql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
			
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from student where status='living'");
			while(rs.next())
			{
				model.addRow(new Object[] {rs.getString(2),rs.getString(1),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(47),rs.getString(8),rs.getString(9)});
				
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		AllStudentsLiving = new JFrame();
		AllStudentsLiving.getContentPane().setBackground(new Color(255, 182, 193));
		AllStudentsLiving.setBounds(0, 0, 800, 500);
		AllStudentsLiving.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setBounds(722, 11, 52, 32);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				home h=new home();
				h.home.setVisible(true);		
				}
		});
		AllStudentsLiving.getContentPane().setLayout(null);
		btnNewButton.setIcon(new ImageIcon(AllStudentsLiving.class.getResource("/images/Close all jframe.png")));
		AllStudentsLiving.getContentPane().add(btnNewButton);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(42, 59, 675, 373);
		AllStudentsLiving.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Name", "Mobile Number", "Father Name", "Mother name", "Email", "Address", "College Name", "Adhaar Number", "Room Number"
			}
		));
		scrollPane.setViewportView(table);
	}

}
