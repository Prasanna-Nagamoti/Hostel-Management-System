import java.awt.EventQueue;

import javax.swing.JFrame;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.JTextPane;

public class home {

	 JFrame home;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					home window = new home();
					window.home.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		home = new JFrame();
		home.getContentPane().addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
			}
		});
		home.setBounds(0, 0, 1366, 770);
		home.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnNewButton = new JButton("Manage Room");
		btnNewButton.setBounds(39, 179, 241, 30);
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton.setIcon(new ImageIcon(home.class.getResource("/images/room.png")));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton.setForeground(Color.red);
				btnNewButton.setForeground(new Color(255,0,0));
				ManageRoom mr=new ManageRoom();
				mr.ManageRoom.setVisible(true);
				
			}
		});
		home.getContentPane().setLayout(null);
		home.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New Student");
		btnNewButton_1.setBounds(39, 261, 241, 30);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton_1.setForeground(Color.red);
				btnNewButton_1.setForeground(new Color(255,0,0));
				NewStudent ns=new NewStudent();
				ns.NewStudent.setVisible(true);
			}
			
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_1.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_1.setIcon(new ImageIcon(home.class.getResource("/images/new student.png")));
		home.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update & Delete Student");
		btnNewButton_2.setBounds(39, 340, 241, 30);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton_2.setForeground(Color.red);
				btnNewButton_2.setForeground(new Color(255,0,0));
				UpdateDeleteStudents u=new UpdateDeleteStudents();
				u.UpdateDeleteStudents.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_2.setIcon(new ImageIcon(home.class.getResource("/images/Update & Delete Student.png")));
		btnNewButton_2.setHorizontalAlignment(SwingConstants.LEADING);
		home.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Student Fess");
		btnNewButton_3.setBounds(39, 413, 241, 30);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton_3.setForeground(Color.red);
				btnNewButton_3.setForeground(new Color(255,0,0));
				StudentFees sf=new StudentFees();
				sf.StudentFees.setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_3.setIcon(new ImageIcon(home.class.getResource("/images/Fees.png")));
		btnNewButton_3.setHorizontalAlignment(SwingConstants.LEADING);
		home.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("All Student Living");
		btnNewButton_4.setBounds(39, 497, 241, 30);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton_4.setForeground(Color.red);
				btnNewButton_4.setForeground(new Color(255,0,0));
			}
		});
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_4.setIcon(new ImageIcon(home.class.getResource("/images/all student living.png")));
		btnNewButton_4.setHorizontalAlignment(SwingConstants.LEADING);
		home.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_11 = new JButton("Logout");
		btnNewButton_11.setBounds(908, 13, 146, 59);
		btnNewButton_11.setIcon(new ImageIcon(home.class.getResource("/images/logout.png")));
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a=JOptionPane.showConfirmDialog(null,"Are you sure","Select",JOptionPane.YES_NO_OPTION);
				if(a==0)
				{
					
					login obj= new login();
					obj.setVisible(false);
					new login().setVisible(true);
				}
			}
		});
		btnNewButton_11.setBackground(UIManager.getColor("Button.background"));
		btnNewButton_11.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_11.setFont(new Font("Times New Roman", Font.BOLD, 14));
		home.getContentPane().add(btnNewButton_11);
		
		JButton btnNewButton_11_1 = new JButton("Exit");
		btnNewButton_11_1.setBounds(1058, 12, 100, 61);
		btnNewButton_11_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a=JOptionPane.showConfirmDialog(null,"Do you really want to Exit","Select",JOptionPane.YES_NO_OPTION);
				if(a==0)
				{
					System.exit(0);
					
				}
			}
		});
		btnNewButton_11_1.setIcon(new ImageIcon(home.class.getResource("/images/Close all jframe.png")));
		btnNewButton_11_1.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_11_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		home.getContentPane().add(btnNewButton_11_1);
		
		JButton btnNewButton_11_2 = new JButton("Shut Down");
		btnNewButton_11_2.setBounds(1161, 10, 163, 64);
		btnNewButton_11_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a=JOptionPane.showConfirmDialog(null,"Do you really want to Exit","Select",JOptionPane.YES_NO_OPTION);
				if(a==0)
				{
					Runtime runtime=Runtime.getRuntime();
					try
					{
						Process proc = runtime.exec("shutdown -s -t 0");
					}
					catch(Exception ex)
					{
						JOptionPane.showMessageDialog(null,0);
					}
				}
				
			}
		});
		btnNewButton_11_2.setIcon(new ImageIcon(home.class.getResource("/images/shut Down.png")));
		btnNewButton_11_2.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_11_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		home.getContentPane().add(btnNewButton_11_2);
		
		JButton btnNewButton_6 = new JButton("Gallery");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton_6.setForeground(Color.red);
				btnNewButton_6.setForeground(new Color(255,0,0));
				Gallery g=new Gallery();
				g.Gallery.setVisible(true);
			}
		});
		btnNewButton_6.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_6.setIcon(new ImageIcon(home.class.getResource("/images/all student living.png")));
		btnNewButton_6.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_6.setBounds(39, 98, 241, 30);
		home.getContentPane().add(btnNewButton_6);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(home.class.getResource("/images/home background.PNG")));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 1350, 729);
		home.getContentPane().add(lblNewLabel);
	}
}
