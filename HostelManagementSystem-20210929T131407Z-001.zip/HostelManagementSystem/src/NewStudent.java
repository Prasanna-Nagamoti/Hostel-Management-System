import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class NewStudent {
	
	public void clear()
	{
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
		textField_6.setText("");
		textField_7.setText("");
		comboBox.removeAllItems();
		roomNumber();
	}
	public void roomNumber()
	{
		int i=0;
		try 
		{
			Class.forName("com.sql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from room where activate='Yes' and roomStatus='Not Booked'");
			while(rs.next())
			{
				i=1;
				comboBox.addItem(rs.getString(1));
			}
			if(i==0)
			{
				btnNewButton_1.setVisible(false);
				JOptionPane.showMessageDialog(null,"All Rooms are already Booked");
				btnNewButton_1.setVisible(false);
			}
		}
		catch(Exception e)
		{
			
		}
	}

	

	JFrame NewStudent;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JComboBox comboBox; 
	private JButton btnNewButton_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewStudent window = new NewStudent();
					window.NewStudent.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NewStudent() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		NewStudent = new JFrame();
		NewStudent.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentShown(ComponentEvent e) {
			roomNumber();
			}
		});
		NewStudent.getContentPane().setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.setBounds(0, 0, 700, 500);
		NewStudent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		NewStudent.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				home h=new home();
				h.home.setVisible(true);
			}
		});
		btnNewButton.setBounds(626, 11, 48, 32);
		btnNewButton.setIcon(new ImageIcon(NewStudent.class.getResource("/images/Close all jframe.png")));
		NewStudent.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Mobile Number");
		lblNewLabel.setBounds(32, 66, 195, 17);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(32, 100, 195, 18);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Father Name");
		lblNewLabel_2.setBounds(32, 137, 195, 18);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Mother Name");
		lblNewLabel_3.setBounds(32, 176, 195, 18);
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Email");
		lblNewLabel_4.setBounds(32, 216, 195, 18);
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Permanent Address");
		lblNewLabel_5.setBounds(32, 256, 195, 18);
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("College Name");
		lblNewLabel_6.setBounds(32, 292, 195, 18);
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Adhaar Number(UNIQUE ID)");
		lblNewLabel_7.setBounds(32, 332, 195, 18);
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Room Number");
		lblNewLabel_8.setBounds(32, 376, 195, 18);
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(lblNewLabel_8);
		
		textField = new JTextField();
		textField.setBounds(268, 65, 382, 20);
		textField.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(268, 100, 382, 20);
		textField_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(268, 136, 382, 20);
		textField_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(268, 175, 382, 20);
		textField_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(268, 216, 382, 20);
		textField_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(268, 256, 382, 20);
		textField_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(268, 291, 382, 20);
		textField_6.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(268, 332, 382, 20);
		textField_7.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(textField_7);
		textField_7.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(268, 375, 382, 22);
		comboBox.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(comboBox);
		
		JButton btnNewButton_1 = new JButton("Save");
		btnNewButton_1.setBounds(268, 408, 89, 32);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mobilenumber=textField.getText();
				String name=textField_1.getText();
				String fathername=textField_2.getText();
				String mothername=textField_3.getText();
				String email=textField_4.getText();
				String address=textField_5.getText();
				String college=textField_6.getText();
				String adhaar=textField_7.getText();
				String roomnumber=(String)comboBox.getSelectedItem();
				String status="living";
				try
				{
					Class.forName("com.sql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
					PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?,?)");
					ps.setString(1,mobilenumber);
					ps.setString(2,name);
					ps.setString(3,fathername);
					ps.setString(4,mothername);
					ps.setString(5,email);
					ps.setString(6,address);
					ps.setString(7,college);
					ps.setString(8,adhaar);
					ps.setString(9,roomnumber);
					ps.setString(10,status);
					ps.executeUpdate();
					
					PreparedStatement ps1=con.prepareStatement("update room set roomStatus='Booked' where number=?");
					ps1.setString(1,roomnumber);
					ps1.executeUpdate();
					JOptionPane.showMessageDialog(null,"Successfully updated");
					clear();
					
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null,e); 	
				}
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_1.setIcon(new ImageIcon(NewStudent.class.getResource("/images/save.png")));
		NewStudent.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Clear");
		btnNewButton_2.setBounds(551, 408, 99, 32);
		btnNewButton_2.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
			}
		});
		btnNewButton_2.setIcon(new ImageIcon(NewStudent.class.getResource("/images/clear.png")));
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		NewStudent.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel_10 = new JLabel("New Student");
		lblNewLabel_10.setFont(new Font("Algerian", Font.BOLD, 20));
		lblNewLabel_10.setBounds(10, 11, 195, 32);
		NewStudent.getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setIcon(new ImageIcon(NewStudent.class.getResource("/images/pages background.jpg")));
		lblNewLabel_9.setBounds(0, 0, 684, 461);
		NewStudent.getContentPane().add(lblNewLabel_9);
	}
}
