import java.awt.EventQueue;
import java.sql.*;


import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UpdateDeleteStudents {
	
	public void clear()
	{
		textField.setEditable(true);
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
		textField_6.setText("");
		textField_7.setText("");
		textField_8.setText("");
		comboBox.removeAllItems();
		
	}

	 JFrame UpdateDeleteStudents;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JComboBox comboBox;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateDeleteStudents window = new UpdateDeleteStudents();
					window.UpdateDeleteStudents.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UpdateDeleteStudents() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		UpdateDeleteStudents = new JFrame();
		UpdateDeleteStudents.getContentPane().setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.setBounds(0, 0, 700, 500);
		UpdateDeleteStudents.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		UpdateDeleteStudents.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				home h=new home();
				h.home.setVisible(true);
			}
		});
		btnNewButton.setBounds(623, 11, 51, 33);
		btnNewButton.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/Close all jframe.png")));
		UpdateDeleteStudents.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Mobile Number");
		lblNewLabel.setBounds(29, 50, 205, 23);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(29, 84, 205, 22);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Father Name");
		lblNewLabel_2.setBounds(29, 117, 205, 22);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Mother Name");
		lblNewLabel_3.setBounds(29, 153, 205, 23);
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Email");
		lblNewLabel_4.setBounds(29, 191, 205, 23);
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Permanent Address");
		lblNewLabel_5.setBounds(29, 228, 205, 23);
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("College Name");
		lblNewLabel_6.setBounds(29, 262, 205, 23);
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Adhaar Number(UNIQUE ID) ");
		lblNewLabel_7.setBounds(29, 297, 205, 23);
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Room Number");
		lblNewLabel_8.setBounds(29, 335, 205, 22);
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Living Status");
		lblNewLabel_9.setBounds(29, 371, 205, 23);
		lblNewLabel_9.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_9);
		
		textField = new JTextField();
		textField.setBounds(254, 52, 166, 20);
		textField.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(254, 86, 363, 20);
		textField_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(254, 119, 363, 20);
		textField_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(254, 155, 363, 20);
		textField_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(254, 193, 363, 20);
		textField_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(254, 230, 363, 20);
		textField_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(254, 264, 363, 20);
		textField_6.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(254, 299, 363, 20);
		textField_7.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBounds(254, 337, 363, 20);
		textField_8.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(textField_8);
		textField_8.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(254, 372, 363, 22);
		comboBox.setFont(new Font("Times New Roman", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(comboBox);
		
		JButton btnNewButton_1 = new JButton("Search");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mobileNo=textField.getText();
				try {
					Class.forName("com.sql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
				
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("select * from student where mobileNo='"+mobileNo+"'");
					if(rs.first())
					{
						textField.setEditable(false);
						textField_1.setText(rs.getString(1));
						textField_2.setText(rs.getString(2));
						textField_3.setText(rs.getString(3));
						textField_4.setText(rs.getString(4));
						textField_5.setText(rs.getString(5));
						textField_6.setText(rs.getString(6));
						textField_7.setText(rs.getString(7));
						textField_8.setText(rs.getString(8));
						textField_8.setEditable(false);
						if(rs.getString(9).equals("living"))
						{
							comboBox.addItem("living");
							comboBox.addItem("leaved");
						}
						else
						{
							comboBox.addItem("leaved");
							comboBox.addItem("living");
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Student does not Exist");
						clear();
					}
					
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, e);
				}
				
			}
		});
		btnNewButton_1.setBounds(446, 51, 108, 23);
		btnNewButton_1.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/search.png")));
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_1.setHorizontalAlignment(SwingConstants.LEFT);
		UpdateDeleteStudents.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String mobileNo=textField.getText();
				String name=textField_1.getText(); 
				String fathername=textField_2.getText();
				String mothername=textField_3.getText();
				String email=textField_4.getText();
				String address=textField_5.getText();
				String college=textField_6.getText();
				String adhaar=textField_7.getText();
				String roomNo=textField_8.getText();
				String status=(String) comboBox.getSelectedItem();
				try
				{
					Class.forName("com.sql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
					
					Statement st=con.createStatement();
					if(status.equals("living"))
					{
						st.executeUpdate("update room setroomStatus='Booked' where number='"+roomNo+"'");	
					}
					else
						st.executeUpdate("update room setroomStatus='Not Booked' where number='"+roomNo+"'");
				PreparedStatement ps=con.prepareStatement("update student set name=?,father=?,mother=?,email=?,address=?,college=?,adhaar=?,status=? where mobileNo=?");
				ps.setString(1,name);
				ps.setString(2,fathername);
				ps.setString(3,mothername);
				ps.setString(4,email);
				ps.setString(5,address);
				ps.setString(6,college);
				ps.setString(7,adhaar);
				ps.setString(8,status);
				ps.setString(9,mobileNo);
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null,"Successfully Updated");
				clear();
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, e);
				}
			}
		});
		btnNewButton_2.setBounds(240, 416, 117, 34);
		btnNewButton_2.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/Update & Delete Student.png")));
		btnNewButton_2.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Delete");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mobileNo=textField.getText();
				String roomNo=textField_8.getText();
				try
				{
					Class.forName("com.sql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
					Statement st=con.createStatement();
					st.executeUpdate("Delete from student where mobileNo='"+mobileNo+"'");
					st.executeUpdate("update room set roomStatus='Not Booked' where number='"+roomNo+"'");
					JOptionPane.showMessageDialog(null,"Successfully Deleted");
					clear();
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, e);
				}
				
				
			}
		});
		btnNewButton_3.setBounds(393, 418, 99, 31);
		btnNewButton_3.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/delete.png")));
		btnNewButton_3.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Clear");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				clear();
			}
		});
		btnNewButton_4.setBounds(526, 419, 91, 29);
		btnNewButton_4.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/clear.png")));
		btnNewButton_4.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		UpdateDeleteStudents.getContentPane().add(btnNewButton_4);
		
		JLabel lblNewLabel_10 = new JLabel("Update or Delete Students");
		lblNewLabel_10.setFont(new Font("Algerian", Font.BOLD, 20));
		lblNewLabel_10.setBounds(10, 11, 307, 23);
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("");
		lblNewLabel_11.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/pages background.jpg")));
		lblNewLabel_11.setBounds(0, 0, 684, 461);
		UpdateDeleteStudents.getContentPane().add(lblNewLabel_11);
	}
}
