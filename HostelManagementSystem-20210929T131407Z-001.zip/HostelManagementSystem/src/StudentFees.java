import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;


public class StudentFees {

	public void clear()
	{ 
		btnNewButton_2.setVisible(true);
		textField.setEditable(true);
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
		DefaultTableModel dtm=(DefaultTableModel) table.getModel();
		dtm.setRowCount(0);
		
	}
	
	public void tableDeatils()
	{
		DefaultTableModel dtm=(DefaultTableModel) table.getModel();
		dtm.setRowCount(0);
		String mobileNo=textField.getText();
		try
		{
			Class.forName("com.sql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
			
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from fees where mobileNo='"+mobileNo+"'");
			while(rs.next())
			{
				dtm.addRow(new Object[] {rs.getString(2),rs.getString(3)});
				
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	 JFrame StudentFees;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JTable table;
	private JScrollPane scrollPane;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentFees window = new StudentFees();
					window.StudentFees.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentFees() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		StudentFees = new JFrame();
		StudentFees.setBounds(0, 0, 700, 500);
		StudentFees.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		StudentFees.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				home h=new home();
				h.home.setVisible(true);
			}
		});
		btnNewButton.setIcon(new ImageIcon(StudentFees.class.getResource("/images/Close all jframe.png")));
		btnNewButton.setBounds(622, 11, 52, 31);
		StudentFees.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Mobile Number");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		lblNewLabel.setBounds(30, 56, 151, 17);
		StudentFees.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 14));
		lblNewLabel_1.setBounds(30, 94, 151, 20);
		StudentFees.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Email");
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 14));
		lblNewLabel_2.setBounds(30, 132, 151, 20);
		StudentFees.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Room Number");
		lblNewLabel_3.setFont(new Font("Dialog", Font.BOLD, 14));
		lblNewLabel_3.setBounds(30, 169, 151, 20);
		StudentFees.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Month");
		lblNewLabel_4.setFont(new Font("Dialog", Font.BOLD, 14));
		lblNewLabel_4.setBounds(30, 208, 151, 20);
		StudentFees.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Amount to be Paid");
		lblNewLabel_5.setFont(new Font("Dialog", Font.BOLD, 14));
		lblNewLabel_5.setBounds(30, 253, 151, 20);
		StudentFees.getContentPane().add(lblNewLabel_5);
		
		textField = new JTextField();
		textField.setFont(new Font("Dialog", Font.BOLD, 14));
		textField.setBounds(227, 56, 151, 20);
		StudentFees.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_1.setBounds(227, 94, 316, 20);
		StudentFees.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_2.setBounds(227, 132, 316, 20);
		StudentFees.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_3.setBounds(227, 169, 316, 20);
		StudentFees.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_4.setBounds(227, 208, 316, 20);
		StudentFees.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_5.setBounds(227, 253, 316, 20);
		StudentFees.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		btnNewButton_1 = new JButton("Search");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mobileNo=textField.getText();
				SimpleDateFormat dFormat=new SimpleDateFormat("MM-YYYY");
				Date date=new Date();
				String month=dFormat.format(date);
				try
				{
					Class.forName("com.sql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
					
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("select * from student where mobileNo='"+mobileNo+"'and status='living'");
					if(rs.first())
					{
						textField.setEditable(false);
						textField_1.setText(rs.getString(2)); 
						textField_2.setText(rs.getString(5));
						textField_3.setText(rs.getString(9));
						textField_4.setText(month);
						textField_5.setText("6000");
					}
					else 
					{
						JOptionPane.showMessageDialog(null,"Student does not Exist");
					clear();
					}
					tableDeatils();
					
					ResultSet rs1=st.executeQuery("select * from fees inner join student where student.status='living'and fees.month='"+month+"'and fees.mobileNo='"+mobileNo+"'and student.mobileNo='"+mobileNo+"'");
					if(rs1.first())
					{
						btnNewButton_2.setVisible(false);
						JOptionPane.showMessageDialog(null,"Fees is already paid by student for this month");
					}
					
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, e);
				}
				
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_1.setIcon(new ImageIcon(StudentFees.class.getResource("/images/search.png")));
		btnNewButton_1.setBounds(440, 55, 103, 23);
		StudentFees.getContentPane().add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("Save");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mobileNo=textField.getText();
				String month=textField_4.getText();
				String amount=textField_5.getText();
				try
				{
					Class.forName("com.sql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
					
					PreparedStatement ps=con.prepareStatement("insert into fees values(?,?,?)");
					ps.setString(1,mobileNo);
					ps.setString(2,month);
					ps.setString(3,amount);
					ps.executeUpdate();
					tableDeatils();
					JOptionPane.showMessageDialog(null,"Successfylly Updated");
					clear();
					
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, e);
				}
				
			}
		});
		btnNewButton_2.setIcon(new ImageIcon(StudentFees.class.getResource("/images/save.png")));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_2.setBounds(227, 284, 103, 31);
		StudentFees.getContentPane().add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
			}
		});
		btnNewButton_3.setIcon(new ImageIcon(StudentFees.class.getResource("/images/clear.png")));
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_3.setBounds(440, 284, 103, 31);
		StudentFees.getContentPane().add(btnNewButton_3);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 344, 664, 106);
		StudentFees.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
			},
			new String[] {
				"Month", "Amount"
			}
		));
		scrollPane.setViewportView(table);
		
		lblNewLabel_6 = new JLabel("Student Fees");
		lblNewLabel_6.setFont(new Font("Algerian", Font.BOLD, 18));
		lblNewLabel_6.setBounds(10, 17, 196, 25);
		StudentFees.getContentPane().add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setIcon(new ImageIcon(StudentFees.class.getResource("/images/pages background.jpg")));
		lblNewLabel_7.setBounds(0, 0, 684, 461);
		StudentFees.getContentPane().add(lblNewLabel_7);
	}

}
