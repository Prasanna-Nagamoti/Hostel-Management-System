
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;


public class ManageRoom {
	
	public void  clear()
	{
		textField.setText("");
		textField_1.setText("");
		CheckBox1.setSelected(false);
		CheckBox2.setSelected(false);
		
		textField_1.setEditable(false);
	}
	
	public void tableDetails()
	{
		DefaultTableModel dtm=(DefaultTableModel)table.getModel();
		dtm.setRowCount(0);
		try {
			Class.forName("com.sql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from room");
			while(rs.next())
			{
				dtm.addRow(new Object[] {rs.getString(1),rs.getString(2),rs.getString(3)});
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}

	 JFrame ManageRoom;
	 private JTextField textField;
	 private JTextField textField_1;
	 private JCheckBox CheckBox1;
	 private JCheckBox CheckBox2;
	 private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageRoom window = new ManageRoom();
					window.ManageRoom.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ManageRoom() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		ManageRoom = new JFrame();
		ManageRoom.getContentPane().setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.setBounds(0, 0, 700, 500);
		ManageRoom.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ManageRoom.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add New Room");
		lblNewLabel.setBounds(10, 11, 158, 27);
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD, 20));
		ManageRoom.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				home h=new home();
				h.home.setVisible(true);
			}
		});
		btnNewButton.setBounds(630, 11, 44, 32);
		btnNewButton.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/Close all jframe.png")));
		ManageRoom.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Room Number");
		lblNewLabel_1.setBounds(10, 68, 94, 20);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(131, 68, 86, 20);
		textField.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Activate or Deactivate");
		lblNewLabel_2.setBounds(255, 68, 149, 20);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(lblNewLabel_2);
		
		JCheckBox CheckBox1 = new JCheckBox("Yes");
		CheckBox1.setBounds(442, 67, 59, 23);
		CheckBox1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(CheckBox1);
		
		JButton btnNewButton_1 = new JButton("Save");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String number=textField.getText();
				String activate;
				String roomStatus="Not Booked";
				if(CheckBox1.isSelected())
				{
					activate="Yes";
				}
				else
			{
					activate="No";
			}
				try {
					Class.forName("com.sql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hostel","root","root");
					
					PreparedStatement ps=con.prepareStatement("insert into room"+"(number,activate,roomStatus)"+"values(?,?,?)");
					ps.setString(1,number);
					ps.setString(2,activate);
					ps.setString(3,roomStatus);
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Successfully Updated");
					tableDetails();
					
					clear();
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, e);
					
				}
				
			}
		});
		btnNewButton_1.setBounds(541, 67, 89, 23);
		btnNewButton_1.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/save.png")));
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(btnNewButton_1);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 99, 684, 2);
		ManageRoom.getContentPane().add(separator);
		
		JLabel lblNewLabel_3 = new JLabel("Update & Delete Room");
		lblNewLabel_3.setBounds(10, 124, 249, 27);
		lblNewLabel_3.setFont(new Font("Algerian", Font.BOLD, 20));
		ManageRoom.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Room Number");
		lblNewLabel_4.setBounds(10, 162, 94, 17);
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(lblNewLabel_4);
		
		textField_1 = new JTextField();
		textField_1.setBounds(131, 159, 86, 20);
		textField_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Activate or Deactivate");
		lblNewLabel_5.setBounds(383, 162, 149, 18);
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(lblNewLabel_5);
		
		JCheckBox CheckBox2 = new JCheckBox("Yes");
		CheckBox2.setBounds(571, 159, 59, 23);
		CheckBox2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(CheckBox2);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.setBounds(419, 202, 113, 23);
		btnNewButton_2.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/save.png")));
		btnNewButton_2.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Delete");
		btnNewButton_3.setBounds(562, 202, 99, 23);
		btnNewButton_3.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/delete.png")));
		btnNewButton_3.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ManageRoom.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Search");
		btnNewButton_4.setBounds(255, 159, 105, 23);
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_4.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/search.png")));
		btnNewButton_4.setHorizontalAlignment(SwingConstants.LEFT);
		ManageRoom.getContentPane().add(btnNewButton_4);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(0, 236, 684, 2);
		ManageRoom.getContentPane().add(separator_1);
		
		JLabel lblNewLabel_6 = new JLabel("All Rooms");
		lblNewLabel_6.setBounds(219, 248, 220, 27);
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Algerian", Font.BOLD, 20));
		ManageRoom.getContentPane().add(lblNewLabel_6);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(103, 299, 468, 106);
		ManageRoom.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"Number", "Activate", "Room Status"
			}
		));
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/pages background.jpg")));
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setBounds(0, 0, 684, 461);
		ManageRoom.getContentPane().add(lblNewLabel_7);
	}
}
