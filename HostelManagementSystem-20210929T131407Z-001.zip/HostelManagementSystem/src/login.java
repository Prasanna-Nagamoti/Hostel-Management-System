
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField user;
	private JPasswordField pass;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setBounds(782, 276, 83, 14);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblNewLabel);
		
		user = new JTextField();
		user.setBounds(695, 303, 250, 20);
		contentPane.add(user);
		user.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(782, 347, 73, 14);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		contentPane.add(lblNewLabel_1);
		
		pass = new JPasswordField();
		pass.setBounds(695, 372, 250, 20);
		contentPane.add(pass);
		
		JCheckBox CheckBox = new JCheckBox("Show Password");
		CheckBox.addActionListener(new ActionListener() {
			

			public void actionPerformed(ActionEvent e) {
				if(CheckBox.isSelected())
				{
					pass.setEchoChar((char)0);
				}
				else
				{
					pass.setEchoChar('*');
				}
			}
		});
		CheckBox.setBounds(695, 399, 105, 23);
		CheckBox.setFont(new Font("Times New Roman", Font.BOLD, 12));
		contentPane.add(CheckBox);
		
		JButton btnNewButton = new JButton("Login ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(user.getText().equals("admin")&& pass.getText().equals("admin"))
				{
					setVisible(false);
					home h=new home();
					h.home.setVisible(true);
				}
				else
				
					JOptionPane.showMessageDialog(null,"Invalid Username or Password");
				
				
			}
		});
		btnNewButton.setBounds(767, 430, 105, 23);
		btnNewButton.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton.setIcon(new ImageIcon(login.class.getResource("/images/login.png")));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a=JOptionPane.showConfirmDialog(null, "Do you want to Exit Application","Select",JOptionPane.YES_NO_OPTION);
				if(a==0)
				{
					System.exit(0);
				}
			}
		});
		btnNewButton_1.setBounds(1267, 11, 73, 63);
		btnNewButton_1.setIcon(new ImageIcon(login.class.getResource("/images/Close.png")));
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(login.class.getResource("/images/login background.PNG")));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(0, 0, 1350, 729);
		contentPane.add(lblNewLabel_3);
	}
}
